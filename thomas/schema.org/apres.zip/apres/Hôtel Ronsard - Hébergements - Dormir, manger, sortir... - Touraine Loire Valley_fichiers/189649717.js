/* Eulerian Analytics #1658570836 */
_oEa.website("touraineloirevalley-fr");
var _EaCP = {"cgip" : _oEa.hcgi
,"tp":{"":""}
};
_oEa.websiteend();
