var Crtc = {};

function set_js_active() {
	$$('body').addClass("js_active");
}
var myShow;

window.addEvent('domready', function() {

	if ($("main_nav")) {
		select_list($$("#main_nav .niveau_1"));
	}
	if ($$(".select_list")) {
		select_list($$(".select_list"));
	}
	if ($$(".slideshow").length > 0) {
		// slide_show();
	}
	if ($$(".highslide-prepage").length > 0) {
		show_prepage();
	}
	lien_blank();

});

/**
 * Listes deroulantes
 */
function select_list(div) {
	div.each(function(el, index) {
		el.set("tabindex", "0");
		var open = function() {
			el.addClass("open");
		}
		var close = function() {
			el.removeClass("open");
		}
		el.addEvent("mouseover", open);
		el.addEvent("focus", open);
		el.addEvent("mouseout", close);
		var last_a = el.getElements('a').getLast();
		if (last_a) {
			last_a.addEvent("blur", close);
		}
	});
}

/**
 * Liens dans une nouvelle fenêtre
 */
function lien_blank() {

	var links = $$('a[rel=external]');
	links.each(function(link) {
		var title = "";
		if (link.get('title')) {
			title = link.get('title') + " ";
		} else {
			for ( var i = 0; i < link.childNodes.length; i++) {
				if (link.childNodes[i].nodeName == 'IMG') {
					title += link.childNodes[i].attributes['alt'].nodeValue
							.trim()
							+ " ";
				} else {
					try {
						title += link.childNodes[i].textContent.trim() + " ";
					} catch (err) {

					}
				}
			}
		}
		link.set('title', title + '(nouvelle fenêtre)');
		link.addEvent('click', function() {
			window.open(this.href);
			return false;
		});
	});
}

/**
 * slideshow d'images dans les pages offres
 */
var compteur_slideshow = 0;
function slide_show_prev() {
	if (compteur_slideshow == 0) {
		myShow.pause();
	}
	myShow.prev();
	compteur_slideshow++;
	setTimeout("slide_show_play()", 5000);
}
function slide_show_next() {
	if (compteur_slideshow == 0) {
		myShow.pause();
	}
	myShow.next();
	compteur_slideshow++;
	setTimeout("slide_show_play()", 5000);
}
function slide_show_play() {
	if (compteur_slideshow == 1) {
		myShow.pause();
		compteur_slideshow = 0;
	} else if (compteur_slideshow > 0) {
		compteur_slideshow--;
	}
}

function show_hide(elt_id) {
	var elt = $(elt_id);
	if (elt.hasClass('hidden')) {
		elt.removeClass('hidden');
	} else {
		elt.addClass('hidden');
	}
}

function slide_show(data, height) {
	/*
	 * var data = { 'image_medium3.jpg': { 'caption': 'Légende de l\'image 3
	 * <cite>&copy; Crédit photo</cite>' }, 'image_medium4.jpg': { 'caption':
	 * 'Légende de l\'image 4 <cite>&copy; Crédit photo</cite>' },
	 * 'image_medium5.jpg': { 'caption': 'Légende de l\'image 5 <cite>&copy;
	 * Crédit photo</cite>' }, 'image_medium6.jpg': { 'caption': 'Légende de
	 * l\'image 6 <cite>&copy; Crédit photo</cite>' }, 'image_medium7.jpg': {
	 * 'caption': 'Légende de l\'image 7 <cite>&copy; Crédit photo</cite>' } };
	 */

	// Show thumbnails for more than one image
	var thumbnails = ( Object.getLength(data) > 1 );

	height = height || 176;
	if (myShow)
		myShow.destroy();
	myShow = new Slideshow('show', data, {
		loader : false,
		controller : false,
		captions : true,
		height : height,
		hu : '',
		thumbnails : thumbnails,
		width : 285,
		linked : false
	});

	if ($$(".slideshow-images")) {
		var zoom = new Element('a', {
			'class' : 'zoom',
			'href' : '#'
		});
		zoom.set('slideshow', myShow);
		$$(".slideshow-images").grab(zoom, 'bottom');
	}

	if ($$(".slideshow-thumbnails")) {
		var controll = new Element('p', {
			'class' : 'controll'
		});
		var precedent = new Element('a', {
			'class' : 'prev',
			'href' : "javascript:slide_show_prev();",
			text : 'Précédent'
		});
		var suivant = new Element('a', {
			'class' : 'next',
			'href' : "javascript:slide_show_next();",
			text : 'Suivant'
		});
		$$(".slideshow-thumbnails").grab(controll, 'before');
		controll.grab(precedent, 'top');
		controll.grab(suivant, 'bottom');
	}
}


/*
 * mootools 1.3-more override
 * 
 * Used to ensure an element id passed to OnElementPass method
 */

Form.Validator.prototype.validateField = function(field, force) {
	if (this.paused)
		return true;
	field = document.id(field);
	var passed = !field.hasClass('validation-failed');
	var failed, warned;
	if (this.options.serial && !force) {
		failed = this.element.getElement('.validation-failed');
		warned = this.element.getElement('.warning');
	}
	if (field
			&& (!failed || force || field.hasClass('validation-failed') || (failed && !this.options.serial))) {
		var validators = field.className.split(' ').some(function(cn) {
			return this.getValidator(cn);
		}, this);
		var validatorsFailed = [];
		field.className.split(' ').each(function(className) {
			if (className && !this.test(className, field))
				validatorsFailed.include(className);
		}, this);
		passed = validatorsFailed.length === 0;
		if (validators && !field.hasClass('warnOnly')) {
			if (passed) {
				field.addClass('validation-passed').removeClass(
						'validation-failed');
				this.fireEvent('elementPass', [ field ]);
			} else {
				field.addClass('validation-failed').removeClass(
						'validation-passed');
				this.fireEvent('elementFail', [ field, validatorsFailed ]);
			}
		}
		if (!warned) {
			var warnings = field.className.split(' ').some(function(cn) {
				if (cn.test('^warn-') || field.hasClass('warnOnly'))
					return this.getValidator(cn.replace(/^warn-/, ''));
				else
					return null;
			}, this);
			field.removeClass('warning');
			var warnResult = field.className.split(' ').map(function(cn) {
				if (cn.test('^warn-') || field.hasClass('warnOnly'))
					return this.test(cn.replace(/^warn-/, ''), field, true);
				else
					return null;
			}, this);
		}
	}
	return passed;
}

/**
 * Add this
 */
window.addEvent('domready', function() {
	if ($('addThis')) {
		// new
		// Asset.javascript('http://s7.addthis.com/js/250/addthis_widget.js');
		$('addThis').addEvents({
			'mouseover' : function() {
				return addthis_open(this, '', '[URL]', '[TITLE]');
			},
			'mouseout' : function() {
				addthis_close();
			},
			'click' : function() {
				return addthis_sendto();
			}
		})
	}
	var addThisLink = $$('.addThis');
	addThisLink.each(function(link) {
		link.addEvents({
			'mouseover' : function() {
				return addthis_open(link, '', link.href, link.title);
			},
			'mouseout' : function() {
				addthis_close();
			},
			'click' : function() {
				return addthis_sendto();
			}
		});
	})
});
