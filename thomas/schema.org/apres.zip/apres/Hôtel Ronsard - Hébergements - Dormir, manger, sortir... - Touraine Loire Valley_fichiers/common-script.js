window.addEvent( 'domready', function() {
	if($$(".sommaire_accordeon").length>0){
        sommaire_accordeon();
    }
});

function addLoadListener(func) {
    if (window.addEventListener) {
        window.addEventListener("load", func, false);
    } else if (window.attachEvent) {
        window.attachEvent("onload", func);
    }
}

/* 
Chapitres : accordeon :  forme des sections pour H2 
*/
function sommaire_accordeon() {
	
	// On ajoute les classe section au H3
	var all_element = $('repereArticle').getChildren();
	
	var tabElt = [];
	var tabSection = [];
	var cpt = 0;
	var new_div_section = false;


	// On forme les accordeons
	//    var myAccordion = new Accordion($$('#repereArticle h2'), $$('.sommaire_accordeon .section'), {
    var myAccordion = new Accordion($$('#repereArticle h2'), $$('#repereArticle p'), {
        display:-1,
        alwaysHide:true,
        onActive: function(toggler) {        	
        	$$(toggler).addClass('moins');
    	},
        onBackground: function(toggler) {        	
        	$$(toggler).removeClass('moins');
        }
    });
}
