
//*************** INTITIALISATION DE LA LISTE DES CARTES **********************

var listeMaps = Array();
var maps = {};
var markerClusters = {};
var gmarkers = {};
var kmlLayerUrl = ''

//***************** FONCTIONS GOOGLE MAPS ***********************************

// A function to create the marker and set up the event window function 
function createMarker( blockId, key, options ) {
    /* #13436 - Carto sentier rando / Picto 14 - Bug avec l'optimisation des marqueurs */
    options.optimized = false;
    var marker = new google.maps.Marker(options);
    if(key){
    	google.maps.event.addListener( marker, 'click', function() {
    		// si la vue est déjà chargée, on évite une requete ajax
    		var popup_html = marker.get('popup_html');
    		if(popup_html){
    			infowindow.setContent(popup_html);
    			infowindow.open(maps[blockId], marker);
    		}
    		else{
        		var req = new Request.HTML({
        			method: 'get',
        			url: '/gmap/popup/' + key,
        			onSuccess: function(tree, elts, html){
        				marker.set('popup_html', html);		 // < on store le contenu de la vue dans le noeud
        				infowindow.setContent(html);
        				infowindow.open(maps[blockId], marker);
        			}
        		}).send();
    		}
    	})
    }
    
    return marker;
}
 
function displayMap( tab )
{
  var blockId = tab[0];
  var download_url = tab[1];
  var zoom = parseInt( tab[2] );
  var center = tab[3];
  var centerLatLng = new google.maps.LatLng(center[0],center[1]);
  var kmlLayerUrl = tab[5];
  var autocenter = tab[6];
  var autozoom = tab[7];
  var showcenter = false;
  if ( tab.length >= 9 ) showcenter = tab[8];
  // create the map
  var myOptions = {
    zoom: zoom,
    center: centerLatLng,
    mapTypeControl: true,
    mapTypeControlOptions: {style: google.maps.MapTypeControlStyle.DROPDOWN_MENU},
    navigationControl: true,
    mapTypeId: google.maps.MapTypeId.ROADMAP
  }
  maps[blockId] = new google.maps.Map(document.getElementById(blockId), myOptions);
  
  if ( kmlLayerUrl != '' )
  {
      var kmlLayer = new google.maps.KmlLayer( kmlLayerUrl,{preserveViewport: true} );
      kmlLayer.setMap(maps[blockId]);
  }

  google.maps.event.addListener(maps[blockId], 'click', function() {
        if(infowindow)
        {
        	infowindow.close();
        }
  });
  markerClusters[blockId] = new MarkerClusterer(maps[blockId], gmarkers[blockId]);
  var coords;
  var myLatLng;
  var options;
  var node_ids;

  // ajouté pour fractionner l'appel ajax
  // première requète récupère les 100 premiers éléments et compte le nombre total
  downloadUrl( download_url+'/(limit)/'+100+'/(offset)/'+0+'/(count)/1' , function(doc) {
    var resul = JSON.decode( doc );

    if(resul[0])
    {
      afficheMarkers(resul[0], blockId, autozoom, autocenter);
    }
    else
    {
      afficheMarkers(resul, blockId, autozoom, autocenter); 
    }
    
    if(resul[1])
    {
      // une fois le nombre d'éléments récuperé on fractionne 
      var nbSrit = resul[1];

      if (nbSrit > 100)
      {
        for(var offset=100;offset<=nbSrit;offset=offset+100)
        {
          downloadUrl( download_url+'/(limit)/'+100+'/(offset)/'+offset , function(doc) {
            var markers = JSON.decode( doc );
            afficheMarkers(markers, blockId, autozoom, autocenter);
          });
        }
      }
    }
  });
  if ( showcenter )
  {
      addAdditionalContent( centerLatLng, maps[blockId] );
  }
}

function addAdditionalContent( latlng, map )
{
    var marker = new google.maps.Marker({ position: latlng,
                                        map: map,
                                        icon: '/extension/crtc_socle/design/crtc_socle/images/pictos/gmap_pin.png'
    });
}
 
function afficheMarkers(markers, blockId, autozoom, autocenter)
{
    gmarkers[blockId] = [];
    var bounds = new google.maps.LatLngBounds();
    if(Object.getLength(markers)>0)
    {    
        for (var k in markers) {
            var coords = k.split(';');
            var myLatLng = new google.maps.LatLng( parseFloat(coords[0]), parseFloat(coords[1]) );
            var options = { 'position': myLatLng };
            var node_ids = [];
            
            for (var i = 0; i < markers[k].length; i++) {
                var node = markers[k][i];
                node_ids.push(node.id);
            }
            
            // picto personnalisé - uniquement si un seul node pour le point
            if(node_ids.length == 1 && markers[k][0].icon){
                var icon = markers[k][0].icon;
                options.icon = new google.maps.MarkerImage( icon.url, new google.maps.Size( icon.width, icon.height ) );
            }
            var marker = createMarker( blockId, node_ids.join('|'), options );
            gmarkers[blockId].push(marker);
            
            bounds.extend(myLatLng);
            
        }
        markerClusters[blockId].addMarkers(gmarkers[blockId]);
        if ( autozoom )
        {
            setTimeout(function() { 
                       maps[blockId].fitBounds(bounds);
                       }, 500 );
        }
        else if ( autocenter )
        {
            setTimeout(function() { 
                       maps[blockId].setCenter(bounds.getCenter());
                       }, 500 );
        }
        
    }
}
 
var infowindow = new google.maps.InfoWindow(
{ 
    size: new google.maps.Size(215,100),
	maxWidth:215
});

window.addEvent('domready', function(){
        for(var j=0; j<listeMaps.length; j++)
        {
            var tab = listeMaps[j];
            displayMap( tab );
        }
} );

/*************************************
 * Zoom
 * **********************************/
 
var myPos, myZoom;
function savePos( map ) {
    myPos = map.getCenter();
    myZoom = map.getZoom();
}

function restorePos( map ) {
    map.setCenter(myPos);
    map.setZoom(myZoom);
}


window.addEvent('domready', function(){
	// we store the original map sizes
	var map_sizes = {};
	for(map_id in maps){
		map_sizes[map_id] = {
			width: $(map_id).getWidth(),
			height: $(map_id).getHeight()
		};
	}
		
	
	$$('#content .map .zoom').addEvents({
		'click':function(e){
			var map_elem = this.getPrevious('div[id^=map]');
			var container = this.getParents('div.map')[0];
			var map = maps[map_elem.id];
			var picto = this.getChildren('img')[0];
			var that = this;

			savePos( map );
			
			if(container.hasClass('full_screen')){
				// we set full screen mode off
				container.removeClass('full_screen');
				$$("iframe").setStyle("display","block");
				container.setStyles({
					'top': 0,
					'left': 0
				});
				map_elem.setStyles({
					'width': map_sizes[map_elem.id].width,
					'height': map_sizes[map_elem.id].height
				});

				picto.setProperty( 'src', picto.getProperty('src').replace(/picto_zoom_out.png$/, 'picto_zoom.png') );
				
				//map.disableScrollWheelZoom();
			    //map.disableDragging();
			    //map.disableContinuousZoom();
			    //map.disableDoubleClickZoom();
			}
			else{
				// we set full screen mode on
				var width = document.documentElement.clientWidth;
				var height = document.documentElement.clientHeight;
				var diff = {
					x: container.getWidth() - map_elem.getWidth(),
					y: container.getHeight() - map_elem.getHeight()
				};
				
				$$("iframe").setStyle("display","none");
				container.addClass('full_screen');
				container.setStyles({
					'top':	window.getScroll().y,
					'left': window.getScroll().x
				});
				map_elem.setStyles({
					'width': width - diff.x,
					'height': height - diff.y
				});
				
				picto.setProperty( 'src', picto.getProperty('src').replace(/picto_zoom.png$/, 'picto_zoom_out.png') );
				
				//map.enableScrollWheelZoom();
			    //map.enableDragging();
			    //map.enableDoubleClickZoom();
			}

			google.maps.event.trigger(map, 'resize');

			restorePos( map );
		}
	});
});


